<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Morin</title>

    <link rel="icon" href="<?php echo e(asset('favicon.ico')); ?>">
    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="<?php echo e(asset('adminlte/plugins/fontawesome-free/css/all.min.css')); ?>">
    <!-- IonIcons -->
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo e(asset('adminlte/dist/css/adminlte.min.css')); ?>">
    <!-- Datatable CSS -->
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.3/css/jquery.dataTables.min.css">
    <link rel="stylesheet" type="text/css"
        href="https://cdn.datatables.net/buttons/1.6.1/css/buttons.dataTables.min.css">

</head>

<body class="hold-transition sidebar-mini layout-fixed">
    <div class="wrapper">
        <!-- Navbar -->
        <nav class="main-header navbar navbar-expand navbar-white navbar-light">
            <!-- Left navbar links -->
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i
                            class="fas fa-bars"></i></a>
                </li>
                <li class="nav-item d-none d-sm-inline-block">
                    <a href="#" class="nav-link">Home</a>
                </li>
                <li class="nav-item d-none d-sm-inline-block">
                    <a href="#" class="nav-link">Contact</a>
                </li>
            </ul>

            <!-- Right navbar links -->
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" data-widget="fullscreen" href="#" role="button">
                        <i class="fas fa-expand-arrows-alt"></i>
                    </a>
                </li>
            </ul>
        </nav>
        <!-- /.navbar -->

        <!-- Main Sidebar Container -->
        <aside class="main-sidebar sidebar-dark-primary elevation-4">
            <!-- Brand Logo -->
            <a href="<?php echo e(url('/penyimpanan')); ?>" class="brand-link">
                <img src="<?php echo e(asset('adminlte/dist/img/morin-logo.png')); ?>" alt="moRin Logo"
                    class="brand-image img-circle elevation-3" style="opacity: .8">
                <span class="brand-text font-weight-light">Morin</span>
            </a>

            <!-- Sidebar -->
            <div class="sidebar">
                <!-- Sidebar user panel (optional) -->
                <div class="user-panel mt-3 pb-3 mb-3 d-flex">
                    <div class="image">
                        <img src="<?php echo e(asset('adminlte/dist/img/woman.png')); ?>" class="img-circle elevation-2"
                            alt="User Image">
                    </div>
                    <div class="info">
                        <a href="#" class="d-block"><?php echo e(Auth::user()->fullname); ?></a>
                    </div>
                </div>

                <?php
                    $allowedUserIds = [1, 2, 4, 18];
                ?>

                <!-- Sidebar Menu -->
                <nav class="mt-2">
                    <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu"
                        data-accordion="false">
                        <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
                        <!-- <li class="nav-item menu-open"> -->
                        <li class="nav-item">
                            <a href="<?php echo e(url('/pembayaran')); ?>" class="nav-link">
                                <i class="nav-icon fas fa-th"></i>
                                <p>
                                    Beranda
                                </p>
                            </a>
                        </li>
                        <li class="nav-header">Data Transaksi Pembayaran</li>
                        <?php if(in_array(Auth::user()->id, $allowedUserIds)): ?>
                            <li class="nav-item">
                                <a href="<?php echo e(url('/pembayaran/create')); ?>" class="nav-link">
                                    <i class="nav-icon fas fa-table"></i>
                                    <p>Input Data</p>
                                </a>
                            </li>
                        <?php endif; ?>
                        <li class="nav-item">
                            <a href="<?php echo e(url('/pembayaran')); ?>" class="nav-link">
                                <i class="nav-icon fas fa-table"></i>
                                <p>
                                    Tabel Pembayaran
                                </p>
                            </a>
                        </li>
                        <li class="nav-header">Data Jenis Pembayaran</li>

                        <?php if(in_array(Auth::user()->id, $allowedUserIds)): ?>
                            <li class="nav-item">
                                <a href="<?php echo e(url('/refpembayaran/create')); ?>" class="nav-link">
                                    <i class="nav-icon fas fa-table"></i>
                                    <p>Input Data</p>
                                </a>
                            </li>
                        <?php endif; ?>
                        <li class="nav-item">
                            <a href="<?php echo e(url('/refpembayaran')); ?>" class="nav-link">
                                <i class="nav-icon fas fa-table"></i>
                                <p>
                                    Tabel Jenis Pembayaran
                                </p>
                            </a>
                        </li>
                        <li class="nav-header">Data Pegawai</li>
                        <li class="nav-item">
                            <a href="<?php echo e(url('/pegawai/')); ?>" class="nav-link">
                                <i class="nav-icon far fa-plus-square"></i>
                                <p>
                                    Tabel Pegawai
                                </p>
                            </a>
                        </li>

                        <li class="nav-header">MISCELLANEOUS</li>
                        <li class="nav-item">
                            <a href="https://1drv.ms/b/s!ApioQiHuoxzikvFottbYMDV8hC3n6g?e=QmhopD" class="nav-link"
                                target="_blank">
                                <i class="nav-icon fas fa-ellipsis-h"></i>
                                <p>Tentang Notikeu</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="https://wa.me/6285265513571" class="nav-link">
                                <i class="nav-icon fas fa-file"></i>
                                <p>Bantuan</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(url('/logout')); ?>" class="nav-link">
                                <i class="nav-icon fas fa-file"></i>
                                <p>Logout</p>
                            </a>
                        </li>
                    </ul>
                </nav>
                <!-- /.sidebar-menu -->
            </div>
            <!-- /.sidebar -->
        </aside>

        <?php echo $__env->yieldContent('content'); ?>

        <!-- Control Sidebar -->
        <aside class="control-sidebar control-sidebar-dark">
            <!-- Control sidebar content goes here -->
        </aside>
        <!-- /.control-sidebar -->

        <!-- Main Footer -->
        <footer class="main-footer">
            <strong>Copyright &copy;2022 <a href="https://padangpanjangkota.bps.go.id">BPS Kota Padang
                    Panjang</a>.</strong>
            All rights reserved.
            <div class="float-right d-none d-sm-inline-block">
                <b>Version</b> 1.0.0
            </div>
        </footer>
    </div>
    <!-- ./wrapper -->

    <!-- jQuery -->
    <script type="text/javascript" src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="<?php echo e(asset('adminlte/plugins/jquery/jquery.min.js')); ?>"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>
    <!-- Bootstrap -->
    <script src="<?php echo e(asset('adminlte/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <!-- AdminLTE -->
    <script src="<?php echo e(asset('adminlte/dist/js/adminlte.js')); ?>"></script>


    <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.6.1/js/dataTables.buttons.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.6.1/js/buttons.flash.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.6.1/js/buttons.html5.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.6.1/js/buttons.print.min.js"></script>


    <!-- OPTIONAL SCRIPTS -->
    <script src="<?php echo e(asset('adminlte/plugins/chart.js/Chart.min.js')); ?>"></script>
    <!-- AdminLTE for demo purposes -->
    <script src="<?php echo e(asset('adminlte/dist/js/demo.js')); ?>"></script>
    <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
    <script src="<?php echo e(asset('adminlte/dist/js/pages/dashboard3.js')); ?>"></script>

    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>

</html>
<?php /**PATH C:\xampp82\htdocs\app\morin\resources\views/template.blade.php ENDPATH**/ ?>