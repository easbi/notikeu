<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0"><i class="fas fa-file-contract"></i> Detail Pengurusan KGB</h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                            <li class="breadcrumb-item"><a href="<?php echo e(route('kgb.index')); ?>">Pengurusan KGB</a></li>
                            <li class="breadcrumb-item active">Detail</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-6">
                        
                        <div class="card">
                            <div class="card-header bg-primary text-white">
                                <h5 class="mb-0"><i class="fas fa-user"></i> Data Pegawai</h5>
                            </div>
                            <div class="card-body">
                                <table class="table table-sm table-bordered">
                                    <tr>
                                        <th width="35%">Nama</th>
                                        <td><?php echo e($pengurusan->nama); ?></td>
                                    </tr>
                                    <tr>
                                        <th>NIP</th>
                                        <td><?php echo e($pengurusan->nip); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Golongan</th>
                                        <td><?php echo e($pengurusan->golongan); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Pangkat</th>
                                        <td><?php echo e($pengurusan->pangkat); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Jabatan</th>
                                        <td><?php echo e($pengurusan->jabatan); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Instansi</th>
                                        <td><?php echo e($pengurusan->instansi); ?></td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-6">
                        
                        <div class="card">
                            <div class="card-header bg-success text-white">
                                <h5 class="mb-0"><i class="fas fa-calendar-alt"></i> Data KGB</h5>
                                <span class="badge badge-<?php echo e($pengurusan->status_badge); ?> float-right">
                                    <?php echo e($pengurusan->status_label); ?>

                                </span>
                            </div>
                            <div class="card-body">
                                <table class="table table-sm table-bordered">
                                    <tr>
                                        <th width="40%">TMT KGB Lama</th>
                                        <td><?php echo e($pengurusan->tmt_kgb_lama ? $pengurusan->tmt_kgb_lama->format('d-m-Y') : '-'); ?>

                                        </td>
                                    </tr>
                                    <tr>
                                        <th>TMT KGB Baru</th>
                                        <td><strong><?php echo e($pengurusan->tmt_kgb_baru->format('d-m-Y')); ?></strong></td>
                                    </tr>
                                    <tr>
                                        <th>Kenaikan y.a.d</th>
                                        <td><?php echo e($pengurusan->tmt_kgb_berikutnya->format('d-m-Y')); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Gaji Pokok Lama</th>
                                        <td><?php echo e($pengurusan->gaji_lama_formatted); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Gaji Pokok Baru</th>
                                        <td><strong><?php echo e($pengurusan->gaji_baru_formatted); ?></strong></td>
                                    </tr>
                                    <tr>
                                        <th>Dasar Peraturan</th>
                                        <td><?php echo e($pengurusan->dasar_peraturan); ?></td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header bg-secondary text-white">
                                <h5 class="mb-0"><i class="fas fa-file-alt"></i> SK KGB</h5>
                            </div>
                            <div class="card-body">
                                <table class="table table-sm table-bordered">
                                    <tr>
                                        <th width="20%">Nomor SK</th>
                                        <td><strong><?php echo e($pengurusan->nomor_sk ?? 'Belum dibuat'); ?></strong></td>
                                    </tr>
                                    <tr>
                                        <th>Tanggal SK</th>
                                        <td><?php echo e($pengurusan->tanggal_sk ? $pengurusan->tanggal_sk->format('d-m-Y') : '-'); ?>

                                        </td>
                                    </tr>
                                    <tr>
                                        <th>Pejabat Penetap</th>
                                        <td><?php echo e($pengurusan->pejabat_penetap ?? '-'); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Masa Kerja Golongan pada tanggal tersebut</th>
                                        <td><?php echo e($pengurusan->masa_kerja_golongan); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Masa Kerja KGB</th>
                                        <td><?php echo e($pengurusan->masa_kerja_kgb); ?></td>
                                    </tr>
                                </table>

                                <?php if($pengurusan->status == 'selesai' && $pengurusan->nomor_sk): ?>
                                    <div class="mt-3">
                                        <a href="<?php echo e(route('kgb.word', $pengurusan->id)); ?>" class="btn btn-primary"
                                            target="_blank">
                                            <i class="fas fa-file-word"></i> Download SK (Word)
                                        </a>

                                        <!-- TOMBOL BATAL PROSES -->
                                        <form action="<?php echo e(route('kgb.batal-proses', $pengurusan->id)); ?>" method="POST"
                                            class="d-inline"
                                            onsubmit="return confirm('Apakah Anda yakin ingin membatalkan proses ini? Gaji pegawai akan dikembalikan ke nilai sebelumnya.')">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="btn btn-warning">
                                                <i class="fas fa-undo"></i> Batal Proses
                                            </button>
                                        </form>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>

                
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header bg-dark text-white">
                                <h5 class="mb-0"><i class="fas fa-list"></i> Log Aktivitas</h5>
                            </div>
                            <div class="card-body">
                                <?php if($pengurusan->logs->count() > 0): ?>
                                    <div class="timeline">
                                        <?php $__currentLoopData = $pengurusan->logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="time-label">
                                                <span class="bg-info"><?php echo e($log->waktu->format('d-m-Y H:i')); ?></span>
                                            </div>
                                            <div>
                                                <i class="fas fa-user bg-primary"></i>
                                                <div class="timeline-item">
                                                    <span class="time"><i class="fas fa-clock"></i>
                                                        <?php echo e($log->waktu->diffForHumans()); ?></span>
                                                    <h3 class="timeline-header">
                                                        <strong><?php echo e($log->nama); ?></strong>
                                                        <span class="badge badge-secondary"><?php echo e($log->aktivitas); ?></span>
                                                    </h3>
                                                    <div class="timeline-body">
                                                        <?php echo e($log->deskripsi); ?>

                                                        <?php if($log->dilakukan_oleh): ?>
                                                            <br><small class="text-muted">Oleh:
                                                                <?php echo e($log->dilakukanOleh->name ?? 'System'); ?></small>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                <?php else: ?>
                                    <p class="text-center text-muted">Belum ada log</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>

                
                <div class="row mt-3">
                    <div class="col-md-12">
                        <a href="<?php echo e(route('kgb.index')); ?>" class="btn btn-secondary">
                            <i class="fas fa-arrow-left"></i> Kembali
                        </a>
                        <?php if($pengurusan->status == 'pending'): ?>
                            <a href="<?php echo e(route('kgb.proses-form', $pengurusan->id)); ?>" class="btn btn-success">
                                <i class="fas fa-edit"></i> Proses KGB
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp82\htdocs\app\morin\resources\views/kgb/show.blade.php ENDPATH**/ ?>